from . import png_overlay

def register():
    png_overlay.register()

def unregister():
    png_overlay.unregister()
