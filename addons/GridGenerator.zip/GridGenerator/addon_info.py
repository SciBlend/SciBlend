bl_info = {
    "name": "Grid Generator",
    "blender": (4, 2, 0),
    "category": "Compositing",
    "version": (2, 0, 0),
    "author": "José Marín",
    "description": "Generates a grid of numbers with advanced functionalities",
    "location": "View3D > Sidebar > Tools",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "support": "COMMUNITY",
}