from . import cinematography_panel

def register():
    cinematography_panel.register()

def unregister():
    cinematography_panel.unregister()